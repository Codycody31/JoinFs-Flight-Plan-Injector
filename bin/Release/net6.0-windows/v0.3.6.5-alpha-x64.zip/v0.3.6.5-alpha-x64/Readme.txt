Use the attached tfl-flightplan.sql file to create the MySQL Database;
then just add the information of the flight and start the Updater!
If something isn't showing always check the log file;
One more thing, the application must run twice for the first time! One to add files and two to for the GUI.
After this if you don't remove any files it will work fine!

Created by: Vahn Gomes, copyright 2022.

